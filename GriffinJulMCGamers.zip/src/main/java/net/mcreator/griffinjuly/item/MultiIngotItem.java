package net.mcreator.griffinjuly.item;

import net.minecraft.world.item.Item;

public class MultiIngotItem extends Item {
	public MultiIngotItem(Item.Properties properties) {
		super(properties);
	}
}