package net.mcreator.griffinjuly.item;

import net.minecraft.world.item.Item;

public class HgvhghthuhghhjjItem extends Item {
	public HgvhghthuhghhjjItem(Item.Properties properties) {
		super(properties);
	}
}