/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.griffinjuly.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.griffinjuly.GriffinJulyMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class GriffinJulyModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, GriffinJulyMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(GriffinJulyModBlocks.HGFHFBUGFBEFUFG.get().asItem());
			tabData.accept(GriffinJulyModBlocks.RFTGFYTYYRGYRYRG.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(GriffinJulyModItems.GFYREUREREYRGYE.get());
			tabData.accept(GriffinJulyModItems.HYFIFRJOIYRT.get());
			tabData.accept(GriffinJulyModItems.YELLOWD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(GriffinJulyModItems.GTFRGFRRRFRYTRUFGR_HELMET.get());
			tabData.accept(GriffinJulyModItems.GTFRGFRRRFRYTRUFGR_CHESTPLATE.get());
			tabData.accept(GriffinJulyModItems.GTFRGFRRRFRYTRUFGR_LEGGINGS.get());
			tabData.accept(GriffinJulyModItems.GTFRGFRRRFRYTRUFGR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(GriffinJulyModItems.YTFGHGFFDGFH_SPAWN_EGG.get());
		}
	}
}