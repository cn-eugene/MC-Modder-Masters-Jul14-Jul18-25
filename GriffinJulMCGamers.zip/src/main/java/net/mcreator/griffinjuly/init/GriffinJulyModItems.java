/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.griffinjuly.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.griffinjuly.item.YellowdItem;
import net.mcreator.griffinjuly.item.MultiIngotItem;
import net.mcreator.griffinjuly.item.HyfifrjoiyrtItem;
import net.mcreator.griffinjuly.item.HgvhghthuhghhjjItem;
import net.mcreator.griffinjuly.item.GtfrgfrrrfrytrufgrItem;
import net.mcreator.griffinjuly.item.GfyreurereyrgyeItem;
import net.mcreator.griffinjuly.GriffinJulyMod;

import java.util.function.Function;

public class GriffinJulyModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(GriffinJulyMod.MODID);
	public static final DeferredItem<Item> HGFHFBUGFBEFUFG = block(GriffinJulyModBlocks.HGFHFBUGFBEFUFG);
	public static final DeferredItem<Item> RFTGFYTYYRGYRYRG = block(GriffinJulyModBlocks.RFTGFYTYYRGYRYRG);
	public static final DeferredItem<Item> MULTI_INGOT = register("multi_ingot", MultiIngotItem::new);
	public static final DeferredItem<Item> HGVHGHTHUHGHHJJ = register("hgvhghthuhghhjj", HgvhghthuhghhjjItem::new);
	public static final DeferredItem<Item> GFYREUREREYRGYE = register("gfyreurereyrgye", GfyreurereyrgyeItem::new);
	public static final DeferredItem<Item> HYFIFRJOIYRT = register("hyfifrjoiyrt", HyfifrjoiyrtItem::new);
	public static final DeferredItem<Item> GTFRGFRRRFRYTRUFGR_HELMET = register("gtfrgfrrrfrytrufgr_helmet", GtfrgfrrrfrytrufgrItem.Helmet::new);
	public static final DeferredItem<Item> GTFRGFRRRFRYTRUFGR_CHESTPLATE = register("gtfrgfrrrfrytrufgr_chestplate", GtfrgfrrrfrytrufgrItem.Chestplate::new);
	public static final DeferredItem<Item> GTFRGFRRRFRYTRUFGR_LEGGINGS = register("gtfrgfrrrfrytrufgr_leggings", GtfrgfrrrfrytrufgrItem.Leggings::new);
	public static final DeferredItem<Item> GTFRGFRRRFRYTRUFGR_BOOTS = register("gtfrgfrrrfrytrufgr_boots", GtfrgfrrrfrytrufgrItem.Boots::new);
	public static final DeferredItem<Item> YTFGHGFFDGFH_SPAWN_EGG = register("ytfghgffdgfh_spawn_egg", properties -> new SpawnEggItem(GriffinJulyModEntities.YTFGHGFFDGFH.get(), properties));
	public static final DeferredItem<Item> YELLOWD = register("yellowd", YellowdItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}