/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.griffinjuly.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.griffinjuly.block.YellowdPortalBlock;
import net.mcreator.griffinjuly.block.RftgfytyyrgyryrgBlock;
import net.mcreator.griffinjuly.block.HgfhfbugfbefufgBlock;
import net.mcreator.griffinjuly.GriffinJulyMod;

import java.util.function.Function;

public class GriffinJulyModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(GriffinJulyMod.MODID);
	public static final DeferredBlock<Block> HGFHFBUGFBEFUFG = register("hgfhfbugfbefufg", HgfhfbugfbefufgBlock::new);
	public static final DeferredBlock<Block> RFTGFYTYYRGYRYRG = register("rftgfytyyrgyryrg", RftgfytyyrgyryrgBlock::new);
	public static final DeferredBlock<Block> YELLOWD_PORTAL = register("yellowd_portal", YellowdPortalBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}