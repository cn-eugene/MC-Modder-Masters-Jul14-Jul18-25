package net.mcreator.griffinjuly.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.griffinjuly.init.GriffinJulyModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements GriffinJulyModBiomes.GriffinJulyModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> griffin_july_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.griffin_july_dimensionTypeReference != null) {
			retval = GriffinJulyModBiomes.adaptSurfaceRule(retval, this.griffin_july_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setgriffin_julyDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.griffin_july_dimensionTypeReference = dimensionType;
	}
}