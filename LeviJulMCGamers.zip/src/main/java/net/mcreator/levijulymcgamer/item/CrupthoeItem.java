
package net.mcreator.levijulymcgamer.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.HoeItem;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class CrupthoeItem extends HoeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 10000, 4f, 0, 509, TagKey.create(Registries.ITEM, ResourceLocation.parse("levi__july_mc_gamer:crupthoe_repair_items")));

	public CrupthoeItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 69f, -3f, properties.fireResistant());
	}
}
