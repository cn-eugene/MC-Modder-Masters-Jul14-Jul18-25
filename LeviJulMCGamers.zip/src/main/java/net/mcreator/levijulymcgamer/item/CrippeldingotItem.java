
package net.mcreator.levijulymcgamer.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class CrippeldingotItem extends Item {
	public CrippeldingotItem(Item.Properties properties) {
		super(properties.rarity(Rarity.COMMON).stacksTo(64));
	}
}
