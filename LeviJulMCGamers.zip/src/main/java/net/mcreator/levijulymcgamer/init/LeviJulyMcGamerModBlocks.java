
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.levijulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.levijulymcgamer.block.ScriptBlock;
import net.mcreator.levijulymcgamer.block.DarkcomandbiockBlock;
import net.mcreator.levijulymcgamer.block.CoruptwoodBlock;
import net.mcreator.levijulymcgamer.LeviJulyMcGamerMod;

import java.util.function.Function;

public class LeviJulyMcGamerModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(LeviJulyMcGamerMod.MODID);
	public static final DeferredBlock<Block> DARKCOMANDBIOCK = register("darkcomandbiock", DarkcomandbiockBlock::new);
	public static final DeferredBlock<Block> SCRIPT = register("script", ScriptBlock::new);
	public static final DeferredBlock<Block> CORUPTWOOD = register("coruptwood", CoruptwoodBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}
