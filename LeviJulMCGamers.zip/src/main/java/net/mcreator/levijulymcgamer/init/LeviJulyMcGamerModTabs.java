
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.levijulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.levijulymcgamer.LeviJulyMcGamerMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class LeviJulyMcGamerModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LeviJulyMcGamerMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.OP_BLOCKS) {
			if (tabData.hasPermissions()) {
				tabData.accept(LeviJulyMcGamerModBlocks.DARKCOMANDBIOCK.get().asItem());
			}
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(LeviJulyMcGamerModBlocks.DARKCOMANDBIOCK.get().asItem());
			tabData.accept(LeviJulyMcGamerModBlocks.SCRIPT.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(LeviJulyMcGamerModItems.CRIPPELDINGOT.get());
			tabData.accept(LeviJulyMcGamerModItems.RAWSCRIPT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(LeviJulyMcGamerModItems.CRIPPLEDSWORD.get());
			tabData.accept(LeviJulyMcGamerModItems.C_0_RUPTSWORD.get());
			tabData.accept(LeviJulyMcGamerModItems.CORUPTPICKAXE.get());
			tabData.accept(LeviJulyMcGamerModItems.CORUPTSHOVEL.get());
			tabData.accept(LeviJulyMcGamerModItems.CRUPTHOE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(LeviJulyMcGamerModItems.CORUPTARMOR_HELMET.get());
			tabData.accept(LeviJulyMcGamerModItems.CORUPTARMOR_CHESTPLATE.get());
			tabData.accept(LeviJulyMcGamerModItems.CORUPTARMOR_LEGGINGS.get());
			tabData.accept(LeviJulyMcGamerModItems.CORUPTARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(LeviJulyMcGamerModItems.SOULCORUPTION_SPAWN_EGG.get());
			tabData.accept(LeviJulyMcGamerModItems.BLAZESOUL_SPAWN_EGG.get());
		}
	}
}
