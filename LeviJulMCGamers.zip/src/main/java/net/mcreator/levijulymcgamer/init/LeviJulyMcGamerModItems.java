
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.levijulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.levijulymcgamer.item.RawscriptItem;
import net.mcreator.levijulymcgamer.item.CrupthoeItem;
import net.mcreator.levijulymcgamer.item.CrippeldingotItem;
import net.mcreator.levijulymcgamer.item.CoruptshovelItem;
import net.mcreator.levijulymcgamer.item.CoruptpickaxeItem;
import net.mcreator.levijulymcgamer.item.CoruptarmorItem;
import net.mcreator.levijulymcgamer.item.CRIPPLEDSWORDItem;
import net.mcreator.levijulymcgamer.item.C0RUPTSWORDItem;
import net.mcreator.levijulymcgamer.LeviJulyMcGamerMod;

import java.util.function.Function;

public class LeviJulyMcGamerModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(LeviJulyMcGamerMod.MODID);
	public static final DeferredItem<Item> DARKCOMANDBIOCK = block(LeviJulyMcGamerModBlocks.DARKCOMANDBIOCK);
	public static final DeferredItem<Item> SCRIPT = block(LeviJulyMcGamerModBlocks.SCRIPT);
	public static final DeferredItem<Item> CRIPPELDINGOT = register("crippeldingot", CrippeldingotItem::new);
	public static final DeferredItem<Item> RAWSCRIPT = register("rawscript", RawscriptItem::new);
	public static final DeferredItem<Item> CRIPPLEDSWORD = register("crippledsword", CRIPPLEDSWORDItem::new);
	public static final DeferredItem<Item> C_0_RUPTSWORD = register("c_0_ruptsword", C0RUPTSWORDItem::new);
	public static final DeferredItem<Item> CORUPTARMOR_HELMET = register("coruptarmor_helmet", CoruptarmorItem.Helmet::new);
	public static final DeferredItem<Item> CORUPTARMOR_CHESTPLATE = register("coruptarmor_chestplate", CoruptarmorItem.Chestplate::new);
	public static final DeferredItem<Item> CORUPTARMOR_LEGGINGS = register("coruptarmor_leggings", CoruptarmorItem.Leggings::new);
	public static final DeferredItem<Item> CORUPTARMOR_BOOTS = register("coruptarmor_boots", CoruptarmorItem.Boots::new);
	public static final DeferredItem<Item> CORUPTPICKAXE = register("coruptpickaxe", CoruptpickaxeItem::new);
	public static final DeferredItem<Item> CORUPTSHOVEL = register("coruptshovel", CoruptshovelItem::new);
	public static final DeferredItem<Item> SOULCORUPTION_SPAWN_EGG = register("soulcoruption_spawn_egg", properties -> new SpawnEggItem(LeviJulyMcGamerModEntities.SOULCORUPTION.get(), properties));
	public static final DeferredItem<Item> CRUPTHOE = register("crupthoe", CrupthoeItem::new);
	public static final DeferredItem<Item> CORUPTWOOD = block(LeviJulyMcGamerModBlocks.CORUPTWOOD);
	public static final DeferredItem<Item> BLAZESOUL_SPAWN_EGG = register("blazesoul_spawn_egg", properties -> new SpawnEggItem(LeviJulyMcGamerModEntities.BLAZESOUL.get(), properties));

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.registerItem(block.getId().getPath(), properties -> new BlockItem(block.get(), properties), new Item.Properties());
	}
}
