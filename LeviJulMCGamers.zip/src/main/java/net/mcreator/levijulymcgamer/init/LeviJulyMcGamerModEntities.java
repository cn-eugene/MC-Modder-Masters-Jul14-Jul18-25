
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.levijulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.levijulymcgamer.entity.SoulcoruptionEntity;
import net.mcreator.levijulymcgamer.entity.BlazesoulEntity;
import net.mcreator.levijulymcgamer.LeviJulyMcGamerMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class LeviJulyMcGamerModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, LeviJulyMcGamerMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<SoulcoruptionEntity>> SOULCORUPTION = register("soulcoruption",
			EntityType.Builder.<SoulcoruptionEntity>of(SoulcoruptionEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(40).setUpdateInterval(3).fireImmune().sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<BlazesoulEntity>> BLAZESOUL = register("blazesoul",
			EntityType.Builder.<BlazesoulEntity>of(BlazesoulEntity::new, MobCategory.AMBIENT).setShouldReceiveVelocityUpdates(true).setTrackingRange(99).setUpdateInterval(3).fireImmune().sized(0.6f, 1.8f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(ResourceKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(LeviJulyMcGamerMod.MODID, registryname))));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		SoulcoruptionEntity.init(event);
		BlazesoulEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(SOULCORUPTION.get(), SoulcoruptionEntity.createAttributes().build());
		event.put(BLAZESOUL.get(), BlazesoulEntity.createAttributes().build());
	}
}
