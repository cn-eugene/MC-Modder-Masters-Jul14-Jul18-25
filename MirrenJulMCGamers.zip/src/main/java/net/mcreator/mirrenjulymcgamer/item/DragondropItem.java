package net.mcreator.mirrenjulymcgamer.item;

import net.minecraft.world.item.Item;

public class DragondropItem extends Item {
	public DragondropItem(Item.Properties properties) {
		super(properties);
	}
}