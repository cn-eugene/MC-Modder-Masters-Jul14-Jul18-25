package net.mcreator.mirrenjulymcgamer.item;

import net.minecraft.world.item.Item;

public class ForestdropItem extends Item {
	public ForestdropItem(Item.Properties properties) {
		super(properties);
	}
}