package net.mcreator.mirrenjulymcgamer.item;

import net.minecraft.world.item.Item;

public class ForestingotItem extends Item {
	public ForestingotItem(Item.Properties properties) {
		super(properties);
	}
}