package net.mcreator.mirrenjulymcgamer.item;

import net.minecraft.world.item.Item;

public class MeltedmesscoreItem extends Item {
	public MeltedmesscoreItem(Item.Properties properties) {
		super(properties.stacksTo(1));
	}
}