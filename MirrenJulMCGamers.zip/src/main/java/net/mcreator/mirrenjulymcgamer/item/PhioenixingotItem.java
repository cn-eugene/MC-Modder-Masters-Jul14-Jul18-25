package net.mcreator.mirrenjulymcgamer.item;

import net.minecraft.world.item.Item;

public class PhioenixingotItem extends Item {
	public PhioenixingotItem(Item.Properties properties) {
		super(properties.stacksTo(32));
	}
}