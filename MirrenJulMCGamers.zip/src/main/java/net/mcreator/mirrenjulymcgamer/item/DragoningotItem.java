package net.mcreator.mirrenjulymcgamer.item;

import net.minecraft.world.item.Item;

public class DragoningotItem extends Item {
	public DragoningotItem(Item.Properties properties) {
		super(properties);
	}
}