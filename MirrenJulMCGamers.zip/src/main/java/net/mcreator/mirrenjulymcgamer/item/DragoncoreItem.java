package net.mcreator.mirrenjulymcgamer.item;

import net.minecraft.world.item.Item;

public class DragoncoreItem extends Item {
	public DragoncoreItem(Item.Properties properties) {
		super(properties.stacksTo(1));
	}
}