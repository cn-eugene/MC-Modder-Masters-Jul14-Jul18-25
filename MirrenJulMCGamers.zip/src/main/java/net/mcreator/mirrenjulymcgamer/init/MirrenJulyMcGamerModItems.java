/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mirrenjulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.mirrenjulymcgamer.item.PhioenixingotItem;
import net.mcreator.mirrenjulymcgamer.item.MeltedmesscoreItem;
import net.mcreator.mirrenjulymcgamer.item.ForestswordtoolItem;
import net.mcreator.mirrenjulymcgamer.item.ForestpickaxeItem;
import net.mcreator.mirrenjulymcgamer.item.ForestingotItem;
import net.mcreator.mirrenjulymcgamer.item.ForestdropItem;
import net.mcreator.mirrenjulymcgamer.item.ForestaxeItem;
import net.mcreator.mirrenjulymcgamer.item.ForestarmorItem;
import net.mcreator.mirrenjulymcgamer.item.DragonswordItem;
import net.mcreator.mirrenjulymcgamer.item.DragonlandsdimensionItem;
import net.mcreator.mirrenjulymcgamer.item.DragoningotItem;
import net.mcreator.mirrenjulymcgamer.item.DragondropItem;
import net.mcreator.mirrenjulymcgamer.item.DragoncoreItem;
import net.mcreator.mirrenjulymcgamer.MirrenJulyMcGamerMod;

import java.util.function.Function;

public class MirrenJulyMcGamerModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(MirrenJulyMcGamerMod.MODID);
	public static final DeferredItem<Item> FORESTORE = block(MirrenJulyMcGamerModBlocks.FORESTORE);
	public static final DeferredItem<Item> FORESTINGOT = register("forestingot", ForestingotItem::new);
	public static final DeferredItem<Item> FORESTSWORDTOOL = register("forestswordtool", ForestswordtoolItem::new);
	public static final DeferredItem<Item> FORESTDROP = register("forestdrop", ForestdropItem::new);
	public static final DeferredItem<Item> FORESTPICKAXE = register("forestpickaxe", ForestpickaxeItem::new);
	public static final DeferredItem<Item> FORESTAXE = register("forestaxe", ForestaxeItem::new);
	public static final DeferredItem<Item> FORESTARMOR_HELMET = register("forestarmor_helmet", ForestarmorItem.Helmet::new);
	public static final DeferredItem<Item> FORESTARMOR_CHESTPLATE = register("forestarmor_chestplate", ForestarmorItem.Chestplate::new);
	public static final DeferredItem<Item> FORESTARMOR_LEGGINGS = register("forestarmor_leggings", ForestarmorItem.Leggings::new);
	public static final DeferredItem<Item> FORESTARMOR_BOOTS = register("forestarmor_boots", ForestarmorItem.Boots::new);
	public static final DeferredItem<Item> MELTEDMESSCORE = register("meltedmesscore", MeltedmesscoreItem::new);
	public static final DeferredItem<Item> DRAGONSWORD = register("dragonsword", DragonswordItem::new);
	public static final DeferredItem<Item> DRAGONBLOCK = block(MirrenJulyMcGamerModBlocks.DRAGONBLOCK, new Item.Properties().rarity(Rarity.RARE));
	public static final DeferredItem<Item> DRAGONINGOT = register("dragoningot", DragoningotItem::new);
	public static final DeferredItem<Item> DRAGONDROP = register("dragondrop", DragondropItem::new);
	public static final DeferredItem<Item> PHIOENIXINGOT = register("phioenixingot", PhioenixingotItem::new);
	public static final DeferredItem<Item> DRAGONCORE = register("dragoncore", DragoncoreItem::new);
	public static final DeferredItem<Item> SEASONBLOCK = block(MirrenJulyMcGamerModBlocks.SEASONBLOCK);
	public static final DeferredItem<Item> FISHTHEPRIDEOFTHERAINBOWLAMAS_SPAWN_EGG = register("fishtheprideoftherainbowlamas_spawn_egg", properties -> new SpawnEggItem(MirrenJulyMcGamerModEntities.FISHTHEPRIDEOFTHERAINBOWLAMAS.get(), properties));
	public static final DeferredItem<Item> DRAGONGRASS = block(MirrenJulyMcGamerModBlocks.DRAGONGRASS);
	public static final DeferredItem<Item> DRAGONDIRT = block(MirrenJulyMcGamerModBlocks.DRAGONDIRT);
	public static final DeferredItem<Item> DRAGONWATERBLOCK = block(MirrenJulyMcGamerModBlocks.DRAGONWATERBLOCK);
	public static final DeferredItem<Item> PORTALBLOCK = block(MirrenJulyMcGamerModBlocks.PORTALBLOCK);
	public static final DeferredItem<Item> DRAGONLANDSDIMENSION = register("dragonlandsdimension", DragonlandsdimensionItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}