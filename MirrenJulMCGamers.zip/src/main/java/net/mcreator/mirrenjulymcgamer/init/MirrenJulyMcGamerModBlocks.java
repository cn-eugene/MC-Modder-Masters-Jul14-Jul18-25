/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mirrenjulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.mirrenjulymcgamer.block.SeasonblockBlock;
import net.mcreator.mirrenjulymcgamer.block.PortalblockBlock;
import net.mcreator.mirrenjulymcgamer.block.ForestoreBlock;
import net.mcreator.mirrenjulymcgamer.block.DragonwaterblockBlock;
import net.mcreator.mirrenjulymcgamer.block.DragonlandsdimensionPortalBlock;
import net.mcreator.mirrenjulymcgamer.block.DragongrassBlock;
import net.mcreator.mirrenjulymcgamer.block.DragondirtBlock;
import net.mcreator.mirrenjulymcgamer.block.DragonblockBlock;
import net.mcreator.mirrenjulymcgamer.MirrenJulyMcGamerMod;

import java.util.function.Function;

public class MirrenJulyMcGamerModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(MirrenJulyMcGamerMod.MODID);
	public static final DeferredBlock<Block> FORESTORE = register("forestore", ForestoreBlock::new);
	public static final DeferredBlock<Block> DRAGONBLOCK = register("dragonblock", DragonblockBlock::new);
	public static final DeferredBlock<Block> SEASONBLOCK = register("seasonblock", SeasonblockBlock::new);
	public static final DeferredBlock<Block> DRAGONGRASS = register("dragongrass", DragongrassBlock::new);
	public static final DeferredBlock<Block> DRAGONDIRT = register("dragondirt", DragondirtBlock::new);
	public static final DeferredBlock<Block> DRAGONWATERBLOCK = register("dragonwaterblock", DragonwaterblockBlock::new);
	public static final DeferredBlock<Block> PORTALBLOCK = register("portalblock", PortalblockBlock::new);
	public static final DeferredBlock<Block> DRAGONLANDSDIMENSION_PORTAL = register("dragonlandsdimension_portal", DragonlandsdimensionPortalBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}