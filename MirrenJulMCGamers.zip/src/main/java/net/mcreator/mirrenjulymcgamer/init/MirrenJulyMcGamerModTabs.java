/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mirrenjulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.mirrenjulymcgamer.MirrenJulyMcGamerMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class MirrenJulyMcGamerModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MirrenJulyMcGamerMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(MirrenJulyMcGamerModBlocks.FORESTORE.get().asItem());
			tabData.accept(MirrenJulyMcGamerModBlocks.DRAGONBLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(MirrenJulyMcGamerModItems.FORESTINGOT.get());
			tabData.accept(MirrenJulyMcGamerModItems.FORESTDROP.get());
			tabData.accept(MirrenJulyMcGamerModItems.MELTEDMESSCORE.get());
			tabData.accept(MirrenJulyMcGamerModItems.DRAGONINGOT.get());
			tabData.accept(MirrenJulyMcGamerModItems.DRAGONDROP.get());
			tabData.accept(MirrenJulyMcGamerModItems.PHIOENIXINGOT.get());
			tabData.accept(MirrenJulyMcGamerModItems.DRAGONCORE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(MirrenJulyMcGamerModItems.FORESTSWORDTOOL.get());
			tabData.accept(MirrenJulyMcGamerModItems.FORESTPICKAXE.get());
			tabData.accept(MirrenJulyMcGamerModItems.FORESTAXE.get());
			tabData.accept(MirrenJulyMcGamerModItems.DRAGONSWORD.get());
			tabData.accept(MirrenJulyMcGamerModItems.DRAGONLANDSDIMENSION.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(MirrenJulyMcGamerModItems.FORESTARMOR_HELMET.get());
			tabData.accept(MirrenJulyMcGamerModItems.FORESTARMOR_CHESTPLATE.get());
			tabData.accept(MirrenJulyMcGamerModItems.FORESTARMOR_LEGGINGS.get());
			tabData.accept(MirrenJulyMcGamerModItems.FORESTARMOR_BOOTS.get());
			tabData.accept(MirrenJulyMcGamerModItems.DRAGONSWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(MirrenJulyMcGamerModBlocks.SEASONBLOCK.get().asItem());
			tabData.accept(MirrenJulyMcGamerModBlocks.PORTALBLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COLORED_BLOCKS) {
			tabData.accept(MirrenJulyMcGamerModBlocks.SEASONBLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(MirrenJulyMcGamerModItems.FISHTHEPRIDEOFTHERAINBOWLAMAS_SPAWN_EGG.get());
		}
	}
}