/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.milesjulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.milesjulymcgamer.MilesJulyMcGamerMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class MilesJulyMcGamerModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MilesJulyMcGamerMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(MilesJulyMcGamerModBlocks.LAVA_0_RE.get().asItem());
			tabData.accept(MilesJulyMcGamerModItems.LAVAINGIT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(MilesJulyMcGamerModItems.ENDSORD.get());
			tabData.accept(MilesJulyMcGamerModItems.Y.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(MilesJulyMcGamerModItems.LAVAARMOR_HELMET.get());
			tabData.accept(MilesJulyMcGamerModItems.LAVAARMOR_CHESTPLATE.get());
			tabData.accept(MilesJulyMcGamerModItems.LAVAARMOR_LEGGINGS.get());
			tabData.accept(MilesJulyMcGamerModItems.LAVAARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(MilesJulyMcGamerModItems.CURUPTIDCHICKEN_SPAWN_EGG.get());
		}
	}
}