/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.milesjulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.milesjulymcgamer.item.YItem;
import net.mcreator.milesjulymcgamer.item.LavaarmorItem;
import net.mcreator.milesjulymcgamer.item.LAVAINGITItem;
import net.mcreator.milesjulymcgamer.item.ENDSORDItem;
import net.mcreator.milesjulymcgamer.MilesJulyMcGamerMod;

import java.util.function.Function;

public class MilesJulyMcGamerModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(MilesJulyMcGamerMod.MODID);
	public static final DeferredItem<Item> JMNJGTK = block(MilesJulyMcGamerModBlocks.JMNJGTK);
	public static final DeferredItem<Item> OPOSITETNT = block(MilesJulyMcGamerModBlocks.OPOSITETNT);
	public static final DeferredItem<Item> LAVA_0_RE = block(MilesJulyMcGamerModBlocks.LAVA_0_RE);
	public static final DeferredItem<Item> LAVAINGIT = register("lavaingit", LAVAINGITItem::new);
	public static final DeferredItem<Item> ENDSORD = register("endsord", ENDSORDItem::new);
	public static final DeferredItem<Item> LAVAARMOR_HELMET = register("lavaarmor_helmet", LavaarmorItem.Helmet::new);
	public static final DeferredItem<Item> LAVAARMOR_CHESTPLATE = register("lavaarmor_chestplate", LavaarmorItem.Chestplate::new);
	public static final DeferredItem<Item> LAVAARMOR_LEGGINGS = register("lavaarmor_leggings", LavaarmorItem.Leggings::new);
	public static final DeferredItem<Item> LAVAARMOR_BOOTS = register("lavaarmor_boots", LavaarmorItem.Boots::new);
	public static final DeferredItem<Item> CURUPTIDCHICKEN_SPAWN_EGG = register("curuptidchicken_spawn_egg", properties -> new SpawnEggItem(MilesJulyMcGamerModEntities.CURUPTIDCHICKEN.get(), properties));
	public static final DeferredItem<Item> H = block(MilesJulyMcGamerModBlocks.H);
	public static final DeferredItem<Item> L = block(MilesJulyMcGamerModBlocks.L);
	public static final DeferredItem<Item> S = block(MilesJulyMcGamerModBlocks.S);
	public static final DeferredItem<Item> Y = register("y", YItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}