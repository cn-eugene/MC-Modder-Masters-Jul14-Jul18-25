/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.milesjulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.milesjulymcgamer.block.YPortalBlock;
import net.mcreator.milesjulymcgamer.block.SBlock;
import net.mcreator.milesjulymcgamer.block.OPOSITETNTBlock;
import net.mcreator.milesjulymcgamer.block.LBlock;
import net.mcreator.milesjulymcgamer.block.LAVA0REBlock;
import net.mcreator.milesjulymcgamer.block.JMNJGTKBlock;
import net.mcreator.milesjulymcgamer.block.HBlock;
import net.mcreator.milesjulymcgamer.MilesJulyMcGamerMod;

import java.util.function.Function;

public class MilesJulyMcGamerModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(MilesJulyMcGamerMod.MODID);
	public static final DeferredBlock<Block> JMNJGTK = register("jmnjgtk", JMNJGTKBlock::new);
	public static final DeferredBlock<Block> OPOSITETNT = register("opositetnt", OPOSITETNTBlock::new);
	public static final DeferredBlock<Block> LAVA_0_RE = register("lava_0_re", LAVA0REBlock::new);
	public static final DeferredBlock<Block> H = register("h", HBlock::new);
	public static final DeferredBlock<Block> L = register("l", LBlock::new);
	public static final DeferredBlock<Block> S = register("s", SBlock::new);
	public static final DeferredBlock<Block> Y_PORTAL = register("y_portal", YPortalBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}