
package net.mcreator.lukejulymcgamer.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.WitchRenderState;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.WitchModel;

import net.mcreator.lukejulymcgamer.entity.LavawitchEntity;

public class LavawitchRenderer extends MobRenderer<LavawitchEntity, WitchRenderState, WitchModel> {
	private LavawitchEntity entity = null;

	public LavawitchRenderer(EntityRendererProvider.Context context) {
		super(context, new WitchModel(context.bakeLayer(ModelLayers.WITCH)), 1f);
	}

	@Override
	public WitchRenderState createRenderState() {
		return new WitchRenderState();
	}

	@Override
	public void extractRenderState(LavawitchEntity entity, WitchRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		this.entity = entity;
	}

	@Override
	public ResourceLocation getTextureLocation(WitchRenderState state) {
		return ResourceLocation.parse("luke_july_mc_gamer:textures/entities/witch.png");
	}
}
