
package net.mcreator.lukejulymcgamer.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class DippednuggetItem extends Item {
	public DippednuggetItem(Item.Properties properties) {
		super(properties.rarity(Rarity.COMMON).stacksTo(64).food((new FoodProperties.Builder()).nutrition(20).saturationModifier(0.3f).alwaysEdible().build()));
	}
}
