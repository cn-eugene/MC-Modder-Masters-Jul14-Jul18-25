
package net.mcreator.lukejulymcgamer.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class FireItem extends Item {
	public FireItem(Item.Properties properties) {
		super(properties.rarity(Rarity.COMMON).stacksTo(64));
	}
}
