
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lukejulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.lukejulymcgamer.LukeJulyMcGamerMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class LukeJulyMcGamerModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LukeJulyMcGamerMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(LukeJulyMcGamerModBlocks.HAPPY.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(LukeJulyMcGamerModItems.FIRE_SWORD.get());
			tabData.accept(LukeJulyMcGamerModItems.FLAMEARMOR_HELMET.get());
			tabData.accept(LukeJulyMcGamerModItems.FLAMEARMOR_CHESTPLATE.get());
			tabData.accept(LukeJulyMcGamerModItems.FLAMEARMOR_LEGGINGS.get());
			tabData.accept(LukeJulyMcGamerModItems.FLAMEARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(LukeJulyMcGamerModBlocks.FIRES.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(LukeJulyMcGamerModItems.FIREAXE.get());
			tabData.accept(LukeJulyMcGamerModItems.JIF.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(LukeJulyMcGamerModItems.FLAMENUGGET.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(LukeJulyMcGamerModItems.LAVAWITCH_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(LukeJulyMcGamerModItems.CHICKENNUGGET.get());
			tabData.accept(LukeJulyMcGamerModItems.PIZZA.get());
			tabData.accept(LukeJulyMcGamerModItems.SLICEOFPIZZA.get());
			tabData.accept(LukeJulyMcGamerModItems.MAC.get());
			tabData.accept(LukeJulyMcGamerModItems.CHICKENWING.get());
			tabData.accept(LukeJulyMcGamerModItems.CANDY.get());
			tabData.accept(LukeJulyMcGamerModItems.BBQ.get());
			tabData.accept(LukeJulyMcGamerModItems.SALAD.get());
			tabData.accept(LukeJulyMcGamerModItems.FRIS.get());
		}
	}
}
