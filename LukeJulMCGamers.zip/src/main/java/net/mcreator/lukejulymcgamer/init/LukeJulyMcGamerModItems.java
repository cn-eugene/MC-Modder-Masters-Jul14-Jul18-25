
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lukejulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.lukejulymcgamer.item.SliceofpizzaItem;
import net.mcreator.lukejulymcgamer.item.SaladItem;
import net.mcreator.lukejulymcgamer.item.PizzaItem;
import net.mcreator.lukejulymcgamer.item.MacItem;
import net.mcreator.lukejulymcgamer.item.JifItem;
import net.mcreator.lukejulymcgamer.item.FrisItem;
import net.mcreator.lukejulymcgamer.item.FlamearmorItem;
import net.mcreator.lukejulymcgamer.item.FireSwordItem;
import net.mcreator.lukejulymcgamer.item.FireItem;
import net.mcreator.lukejulymcgamer.item.FLAMENUGGETItem;
import net.mcreator.lukejulymcgamer.item.FIREAXEItem;
import net.mcreator.lukejulymcgamer.item.DippednuggetItem;
import net.mcreator.lukejulymcgamer.item.ChickenwingItem;
import net.mcreator.lukejulymcgamer.item.ChickennuggetItem;
import net.mcreator.lukejulymcgamer.item.CandyItem;
import net.mcreator.lukejulymcgamer.item.BbqItem;
import net.mcreator.lukejulymcgamer.LukeJulyMcGamerMod;

import java.util.function.Function;

public class LukeJulyMcGamerModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(LukeJulyMcGamerMod.MODID);
	public static final DeferredItem<Item> NINJA = block(LukeJulyMcGamerModBlocks.NINJA);
	public static final DeferredItem<Item> HAPPY = block(LukeJulyMcGamerModBlocks.HAPPY);
	public static final DeferredItem<Item> FIRE = register("fire", FireItem::new);
	public static final DeferredItem<Item> FIRE_SWORD = register("fire_sword", FireSwordItem::new);
	public static final DeferredItem<Item> FLAMEARMOR_HELMET = register("flamearmor_helmet", FlamearmorItem.Helmet::new);
	public static final DeferredItem<Item> FLAMEARMOR_CHESTPLATE = register("flamearmor_chestplate", FlamearmorItem.Chestplate::new);
	public static final DeferredItem<Item> FLAMEARMOR_LEGGINGS = register("flamearmor_leggings", FlamearmorItem.Leggings::new);
	public static final DeferredItem<Item> FLAMEARMOR_BOOTS = register("flamearmor_boots", FlamearmorItem.Boots::new);
	public static final DeferredItem<Item> FIRES = block(LukeJulyMcGamerModBlocks.FIRES);
	public static final DeferredItem<Item> FIREAXE = register("fireaxe", FIREAXEItem::new);
	public static final DeferredItem<Item> FLAMENUGGET = register("flamenugget", FLAMENUGGETItem::new);
	public static final DeferredItem<Item> LAVAWITCH_SPAWN_EGG = register("lavawitch_spawn_egg", properties -> new SpawnEggItem(LukeJulyMcGamerModEntities.LAVAWITCH.get(), properties));
	public static final DeferredItem<Item> CHICKENNUGGET = register("chickennugget", ChickennuggetItem::new);
	public static final DeferredItem<Item> PIZZA = register("pizza", PizzaItem::new);
	public static final DeferredItem<Item> SLICEOFPIZZA = register("sliceofpizza", SliceofpizzaItem::new);
	public static final DeferredItem<Item> MAC = register("mac", MacItem::new);
	public static final DeferredItem<Item> CHICKENWING = register("chickenwing", ChickenwingItem::new);
	public static final DeferredItem<Item> CANDY = register("candy", CandyItem::new);
	public static final DeferredItem<Item> DIPPEDNUGGET = register("dippednugget", DippednuggetItem::new);
	public static final DeferredItem<Item> BBQ = register("bbq", BbqItem::new);
	public static final DeferredItem<Item> F = block(LukeJulyMcGamerModBlocks.F);
	public static final DeferredItem<Item> ASDFHJ = block(LukeJulyMcGamerModBlocks.ASDFHJ);
	public static final DeferredItem<Item> GGGG = block(LukeJulyMcGamerModBlocks.GGGG);
	public static final DeferredItem<Item> HEDYUVHE = block(LukeJulyMcGamerModBlocks.HEDYUVHE);
	public static final DeferredItem<Item> JIF = register("jif", JifItem::new);
	public static final DeferredItem<Item> SALAD = register("salad", SaladItem::new);
	public static final DeferredItem<Item> FRIS = register("fris", FrisItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.registerItem(block.getId().getPath(), properties -> new BlockItem(block.get(), properties), new Item.Properties());
	}
}
