
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lukejulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.lukejulymcgamer.block.NinjaBlock;
import net.mcreator.lukejulymcgamer.block.JifPortalBlock;
import net.mcreator.lukejulymcgamer.block.HedyuvheBlock;
import net.mcreator.lukejulymcgamer.block.HappyBlock;
import net.mcreator.lukejulymcgamer.block.GgggBlock;
import net.mcreator.lukejulymcgamer.block.FIRESBlock;
import net.mcreator.lukejulymcgamer.block.FBlock;
import net.mcreator.lukejulymcgamer.block.AsdfhjBlock;
import net.mcreator.lukejulymcgamer.LukeJulyMcGamerMod;

import java.util.function.Function;

public class LukeJulyMcGamerModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(LukeJulyMcGamerMod.MODID);
	public static final DeferredBlock<Block> NINJA = register("ninja", NinjaBlock::new);
	public static final DeferredBlock<Block> HAPPY = register("happy", HappyBlock::new);
	public static final DeferredBlock<Block> FIRES = register("fires", FIRESBlock::new);
	public static final DeferredBlock<Block> F = register("f", FBlock::new);
	public static final DeferredBlock<Block> ASDFHJ = register("asdfhj", AsdfhjBlock::new);
	public static final DeferredBlock<Block> GGGG = register("gggg", GgggBlock::new);
	public static final DeferredBlock<Block> HEDYUVHE = register("hedyuvhe", HedyuvheBlock::new);
	public static final DeferredBlock<Block> JIF_PORTAL = register("jif_portal", JifPortalBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}

	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			FIRESBlock.blockColorLoad(event);
		}
	}
}
