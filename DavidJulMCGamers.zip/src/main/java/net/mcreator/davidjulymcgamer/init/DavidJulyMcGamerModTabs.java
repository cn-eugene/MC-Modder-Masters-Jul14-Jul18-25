/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.davidjulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.davidjulymcgamer.DavidJulyMcGamerMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class DavidJulyMcGamerModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, DavidJulyMcGamerMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(DavidJulyMcGamerModBlocks.VIODBLOCK.get().asItem());
			tabData.accept(DavidJulyMcGamerModBlocks.EMERALDFRAGNATSORE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(DavidJulyMcGamerModItems.EMERALDFRAGNAT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(DavidJulyMcGamerModItems.SWORDOFTHEDIMENTIONS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(DavidJulyMcGamerModItems.SWORDOFTHEDIMENTIONS.get());
			tabData.accept(DavidJulyMcGamerModItems.DIMENTIONALHELMET_HELMET.get());
			tabData.accept(DavidJulyMcGamerModItems.DIMENTIONALHELMET_CHESTPLATE.get());
			tabData.accept(DavidJulyMcGamerModItems.DIMENTIONALHELMET_LEGGINGS.get());
			tabData.accept(DavidJulyMcGamerModItems.DIMENTIONALHELMET_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(DavidJulyMcGamerModItems.THRASHER_SPAWN_EGG.get());
			tabData.accept(DavidJulyMcGamerModItems.TITANTHRASHER_SPAWN_EGG.get());
		}
	}
}