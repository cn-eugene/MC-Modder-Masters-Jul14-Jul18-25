/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.davidjulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.davidjulymcgamer.item.SwordofthedimentionsItem;
import net.mcreator.davidjulymcgamer.item.EmeraldfragnatItem;
import net.mcreator.davidjulymcgamer.item.DimentionalhelmetItem;
import net.mcreator.davidjulymcgamer.DavidJulyMcGamerMod;

import java.util.function.Function;

public class DavidJulyMcGamerModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(DavidJulyMcGamerMod.MODID);
	public static final DeferredItem<Item> VIODBLOCK = block(DavidJulyMcGamerModBlocks.VIODBLOCK);
	public static final DeferredItem<Item> EMERALDFRAGNAT = register("emeraldfragnat", EmeraldfragnatItem::new);
	public static final DeferredItem<Item> EMERALDFRAGNATSORE = block(DavidJulyMcGamerModBlocks.EMERALDFRAGNATSORE);
	public static final DeferredItem<Item> FRAGNATORE = block(DavidJulyMcGamerModBlocks.FRAGNATORE);
	public static final DeferredItem<Item> SWORDOFTHEDIMENTIONS = register("swordofthedimentions", SwordofthedimentionsItem::new);
	public static final DeferredItem<Item> DIMENTIONALHELMET_HELMET = register("dimentionalhelmet_helmet", DimentionalhelmetItem.Helmet::new);
	public static final DeferredItem<Item> DIMENTIONALHELMET_CHESTPLATE = register("dimentionalhelmet_chestplate", DimentionalhelmetItem.Chestplate::new);
	public static final DeferredItem<Item> DIMENTIONALHELMET_LEGGINGS = register("dimentionalhelmet_leggings", DimentionalhelmetItem.Leggings::new);
	public static final DeferredItem<Item> DIMENTIONALHELMET_BOOTS = register("dimentionalhelmet_boots", DimentionalhelmetItem.Boots::new);
	public static final DeferredItem<Item> THRASHER_SPAWN_EGG = register("thrasher_spawn_egg", properties -> new SpawnEggItem(DavidJulyMcGamerModEntities.THRASHER.get(), properties));
	public static final DeferredItem<Item> TITANTHRASHER_SPAWN_EGG = register("titanthrasher_spawn_egg", properties -> new SpawnEggItem(DavidJulyMcGamerModEntities.TITANTHRASHER.get(), properties));
	public static final DeferredItem<Item> TWILIGHTBLOCK = block(DavidJulyMcGamerModBlocks.TWILIGHTBLOCK);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}