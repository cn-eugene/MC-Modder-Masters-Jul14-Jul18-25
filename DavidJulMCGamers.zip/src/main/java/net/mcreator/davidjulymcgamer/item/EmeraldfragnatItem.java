package net.mcreator.davidjulymcgamer.item;

import net.minecraft.world.item.Item;

public class EmeraldfragnatItem extends Item {
	public EmeraldfragnatItem(Item.Properties properties) {
		super(properties);
	}
}