package net.mcreator.davidjulymcgamer.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.CreeperRenderState;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.CreeperModel;
import net.minecraft.client.animation.definitions.BreezeAnimation;

import net.mcreator.davidjulymcgamer.entity.TitanthrasherEntity;

import com.mojang.blaze3d.vertex.PoseStack;

public class TitanthrasherRenderer extends MobRenderer<TitanthrasherEntity, CreeperRenderState, CreeperModel> {
	private TitanthrasherEntity entity = null;

	public TitanthrasherRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(ModelLayers.CREEPER)), 0.5f);
	}

	@Override
	public CreeperRenderState createRenderState() {
		return new CreeperRenderState();
	}

	@Override
	public void extractRenderState(TitanthrasherEntity entity, CreeperRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		this.entity = entity;
		if (this.model instanceof AnimatedModel) {
			((AnimatedModel) this.model).setEntity(entity);
		}
	}

	@Override
	public ResourceLocation getTextureLocation(CreeperRenderState state) {
		return ResourceLocation.parse("david_july_mc_gamer:textures/entities/creeper_1.png");
	}

	@Override
	protected void scale(CreeperRenderState state, PoseStack poseStack) {
		poseStack.scale(13f, 13f, 13f);
	}

	private static final class AnimatedModel extends CreeperModel {
		private TitanthrasherEntity entity = null;

		public AnimatedModel(ModelPart root) {
			super(root);
		}

		public void setEntity(TitanthrasherEntity entity) {
			this.entity = entity;
		}

		@Override
		public void setupAnim(CreeperRenderState state) {
			this.root().getAllParts().forEach(ModelPart::resetPose);
			this.animate(entity.animationState0, BreezeAnimation.IDLE, state.ageInTicks, 1f);
			super.setupAnim(state);
		}
	}
}