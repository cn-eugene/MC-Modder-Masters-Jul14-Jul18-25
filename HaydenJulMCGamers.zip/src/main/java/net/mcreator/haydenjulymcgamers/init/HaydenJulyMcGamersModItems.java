/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.haydenjulymcgamers.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.haydenjulymcgamers.item.TntswordItem;
import net.mcreator.haydenjulymcgamers.item.TntingotItem;
import net.mcreator.haydenjulymcgamers.item.TntaxeItem;
import net.mcreator.haydenjulymcgamers.item.TntarmorItem;
import net.mcreator.haydenjulymcgamers.item.TNTGunpowderItem;
import net.mcreator.haydenjulymcgamers.item.TNTDemensionItem;
import net.mcreator.haydenjulymcgamers.HaydenJulyMcGamersMod;

import java.util.function.Function;

public class HaydenJulyMcGamersModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(HaydenJulyMcGamersMod.MODID);
	public static final DeferredItem<Item> GRASSTNT = block(HaydenJulyMcGamersModBlocks.GRASSTNT);
	public static final DeferredItem<Item> TNTORE = block(HaydenJulyMcGamersModBlocks.TNTORE);
	public static final DeferredItem<Item> TNTINGOT = register("tntingot", TntingotItem::new);
	public static final DeferredItem<Item> TNTSWORD = register("tntsword", TntswordItem::new);
	public static final DeferredItem<Item> TNTAXE = register("tntaxe", TntaxeItem::new);
	public static final DeferredItem<Item> BOMBYBLOCK = block(HaydenJulyMcGamersModBlocks.BOMBYBLOCK);
	public static final DeferredItem<Item> TNTARMOR_HELMET = register("tntarmor_helmet", TntarmorItem.Helmet::new);
	public static final DeferredItem<Item> TNTARMOR_CHESTPLATE = register("tntarmor_chestplate", TntarmorItem.Chestplate::new);
	public static final DeferredItem<Item> TNTARMOR_LEGGINGS = register("tntarmor_leggings", TntarmorItem.Leggings::new);
	public static final DeferredItem<Item> TNTARMOR_BOOTS = register("tntarmor_boots", TntarmorItem.Boots::new);
	public static final DeferredItem<Item> INSIDE_OUT_CREEPER_SPAWN_EGG = register("inside_out_creeper_spawn_egg", properties -> new SpawnEggItem(HaydenJulyMcGamersModEntities.INSIDE_OUT_CREEPER.get(), properties));
	public static final DeferredItem<Item> TNT_GUNPOWDER = register("tnt_gunpowder", TNTGunpowderItem::new);
	public static final DeferredItem<Item> TNT_SAND = block(HaydenJulyMcGamersModBlocks.TNT_SAND);
	public static final DeferredItem<Item> TNTTNT = block(HaydenJulyMcGamersModBlocks.TNTTNT);
	public static final DeferredItem<Item> TNTDIRT = block(HaydenJulyMcGamersModBlocks.TNTDIRT);
	public static final DeferredItem<Item> STONE_TNT = block(HaydenJulyMcGamersModBlocks.STONE_TNT);
	public static final DeferredItem<Item> TNT_GRAVEL = block(HaydenJulyMcGamersModBlocks.TNT_GRAVEL);
	public static final DeferredItem<Item> TNT_WOOD = block(HaydenJulyMcGamersModBlocks.TNT_WOOD);
	public static final DeferredItem<Item> TNT_LEAVES = block(HaydenJulyMcGamersModBlocks.TNT_LEAVES);
	public static final DeferredItem<Item> TNT_DEMENSION = register("tnt_demension", TNTDemensionItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}