/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.haydenjulymcgamers.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.haydenjulymcgamers.block.TnttntBlock;
import net.mcreator.haydenjulymcgamers.block.TntoreBlock;
import net.mcreator.haydenjulymcgamers.block.TntdirtBlock;
import net.mcreator.haydenjulymcgamers.block.TNTWoodBlock;
import net.mcreator.haydenjulymcgamers.block.TNTSandBlock;
import net.mcreator.haydenjulymcgamers.block.TNTLeavesBlock;
import net.mcreator.haydenjulymcgamers.block.TNTGravelBlock;
import net.mcreator.haydenjulymcgamers.block.TNTDemensionPortalBlock;
import net.mcreator.haydenjulymcgamers.block.StoneTNTBlock;
import net.mcreator.haydenjulymcgamers.block.GrasstntBlock;
import net.mcreator.haydenjulymcgamers.block.BombyblockBlock;
import net.mcreator.haydenjulymcgamers.HaydenJulyMcGamersMod;

import java.util.function.Function;

public class HaydenJulyMcGamersModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(HaydenJulyMcGamersMod.MODID);
	public static final DeferredBlock<Block> GRASSTNT = register("grasstnt", GrasstntBlock::new);
	public static final DeferredBlock<Block> TNTORE = register("tntore", TntoreBlock::new);
	public static final DeferredBlock<Block> BOMBYBLOCK = register("bombyblock", BombyblockBlock::new);
	public static final DeferredBlock<Block> TNT_SAND = register("tnt_sand", TNTSandBlock::new);
	public static final DeferredBlock<Block> TNTTNT = register("tnttnt", TnttntBlock::new);
	public static final DeferredBlock<Block> TNTDIRT = register("tntdirt", TntdirtBlock::new);
	public static final DeferredBlock<Block> STONE_TNT = register("stone_tnt", StoneTNTBlock::new);
	public static final DeferredBlock<Block> TNT_GRAVEL = register("tnt_gravel", TNTGravelBlock::new);
	public static final DeferredBlock<Block> TNT_WOOD = register("tnt_wood", TNTWoodBlock::new);
	public static final DeferredBlock<Block> TNT_LEAVES = register("tnt_leaves", TNTLeavesBlock::new);
	public static final DeferredBlock<Block> TNT_DEMENSION_PORTAL = register("tnt_demension_portal", TNTDemensionPortalBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}

	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			GrasstntBlock.blockColorLoad(event);
		}
	}
}