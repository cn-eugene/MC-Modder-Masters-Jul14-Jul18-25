package net.mcreator.eviejulymcgamer.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class EnderswordItem extends SwordItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 120, 7.5f, 0, 38, TagKey.create(Registries.ITEM, ResourceLocation.parse("evie__july_mc_gamer:endersword_repair_items")));

	public EnderswordItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 29f, -4f, properties);
	}
}