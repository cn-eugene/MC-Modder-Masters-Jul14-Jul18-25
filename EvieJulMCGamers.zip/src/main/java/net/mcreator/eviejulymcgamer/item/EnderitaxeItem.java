package net.mcreator.eviejulymcgamer.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class EnderitaxeItem extends AxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 2500, 205f, 0, 64, TagKey.create(Registries.ITEM, ResourceLocation.parse("evie__july_mc_gamer:enderitaxe_repair_items")));

	public EnderitaxeItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 12.7f, -2.8f, properties);
	}
}