package net.mcreator.eviejulymcgamer.item;

import net.minecraft.world.item.Item;

public class EnderiteingotItem extends Item {
	public EnderiteingotItem(Item.Properties properties) {
		super(properties);
	}
}