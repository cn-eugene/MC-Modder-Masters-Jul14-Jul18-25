/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.eviejulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.eviejulymcgamer.item.EnderswordItem;
import net.mcreator.eviejulymcgamer.item.Endersword2Item;
import net.mcreator.eviejulymcgamer.item.EnderitepigaxeItem;
import net.mcreator.eviejulymcgamer.item.EnderiteingotItem;
import net.mcreator.eviejulymcgamer.item.EnderitearmarItem;
import net.mcreator.eviejulymcgamer.item.EnderitaxeItem;
import net.mcreator.eviejulymcgamer.EvieJulyMcGamerMod;

import java.util.function.Function;

public class EvieJulyMcGamerModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(EvieJulyMcGamerMod.MODID);
	public static final DeferredItem<Item> ERROR = block(EvieJulyMcGamerModBlocks.ERROR);
	public static final DeferredItem<Item> ENDERITE = block(EvieJulyMcGamerModBlocks.ENDERITE);
	public static final DeferredItem<Item> ENDERITEINGOT = register("enderiteingot", EnderiteingotItem::new);
	public static final DeferredItem<Item> ENDERSWORD = register("endersword", EnderswordItem::new);
	public static final DeferredItem<Item> ENDERSWORD_2 = register("endersword_2", Endersword2Item::new);
	public static final DeferredItem<Item> ENDERITEPIGAXE = register("enderitepigaxe", EnderitepigaxeItem::new);
	public static final DeferredItem<Item> ENDERITAXE = register("enderitaxe", EnderitaxeItem::new);
	public static final DeferredItem<Item> ENDERITEARMAR_HELMET = register("enderitearmar_helmet", EnderitearmarItem.Helmet::new);
	public static final DeferredItem<Item> ENDERITEARMAR_CHESTPLATE = register("enderitearmar_chestplate", EnderitearmarItem.Chestplate::new);
	public static final DeferredItem<Item> ENDERITEARMAR_LEGGINGS = register("enderitearmar_leggings", EnderitearmarItem.Leggings::new);
	public static final DeferredItem<Item> ENDERITEARMAR_BOOTS = register("enderitearmar_boots", EnderitearmarItem.Boots::new);
	public static final DeferredItem<Item> END_GRASS = block(EvieJulyMcGamerModBlocks.END_GRASS);
	public static final DeferredItem<Item> END_WOOD = block(EvieJulyMcGamerModBlocks.END_WOOD);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}