/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.eviejulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.eviejulymcgamer.EvieJulyMcGamerMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class EvieJulyMcGamerModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EvieJulyMcGamerMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(EvieJulyMcGamerModBlocks.ERROR.get().asItem());
			tabData.accept(EvieJulyMcGamerModItems.ENDERSWORD.get());
			tabData.accept(EvieJulyMcGamerModItems.ENDERITEPIGAXE.get());
			tabData.accept(EvieJulyMcGamerModItems.ENDERITAXE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(EvieJulyMcGamerModItems.ENDERSWORD_2.get());
			tabData.accept(EvieJulyMcGamerModItems.ENDERITEARMAR_HELMET.get());
			tabData.accept(EvieJulyMcGamerModItems.ENDERITEARMAR_CHESTPLATE.get());
			tabData.accept(EvieJulyMcGamerModItems.ENDERITEARMAR_LEGGINGS.get());
			tabData.accept(EvieJulyMcGamerModItems.ENDERITEARMAR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(EvieJulyMcGamerModBlocks.END_GRASS.get().asItem());
		}
	}
}