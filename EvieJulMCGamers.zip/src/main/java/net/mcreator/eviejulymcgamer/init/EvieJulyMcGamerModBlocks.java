/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.eviejulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.eviejulymcgamer.block.ErrorBlock;
import net.mcreator.eviejulymcgamer.block.EnderiteBlock;
import net.mcreator.eviejulymcgamer.block.EndWoodBlock;
import net.mcreator.eviejulymcgamer.block.EndGrassBlock;
import net.mcreator.eviejulymcgamer.EvieJulyMcGamerMod;

import java.util.function.Function;

public class EvieJulyMcGamerModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(EvieJulyMcGamerMod.MODID);
	public static final DeferredBlock<Block> ERROR = register("error", ErrorBlock::new);
	public static final DeferredBlock<Block> ENDERITE = register("enderite", EnderiteBlock::new);
	public static final DeferredBlock<Block> END_GRASS = register("end_grass", EndGrassBlock::new);
	public static final DeferredBlock<Block> END_WOOD = register("end_wood", EndWoodBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}