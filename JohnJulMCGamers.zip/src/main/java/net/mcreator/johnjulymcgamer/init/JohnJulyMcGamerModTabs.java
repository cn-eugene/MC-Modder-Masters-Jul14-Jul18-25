
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.johnjulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.johnjulymcgamer.JohnJulyMcGamerMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class JohnJulyMcGamerModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, JohnJulyMcGamerMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(JohnJulyMcGamerModBlocks.GREG.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(JohnJulyMcGamerModItems.FIRETHING.get());
			tabData.accept(JohnJulyMcGamerModItems.BANANAICEFIRESWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(JohnJulyMcGamerModItems.BANANA.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(JohnJulyMcGamerModBlocks.GREGPLANT.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(JohnJulyMcGamerModItems.GREGGUY_SPAWN_EGG.get());
			tabData.accept(JohnJulyMcGamerModItems.GLIG_SPAWN_EGG.get());
		}
	}
}
