
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.johnjulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.johnjulymcgamer.item.FirethingItem;
import net.mcreator.johnjulymcgamer.item.BananaicefireswordItem;
import net.mcreator.johnjulymcgamer.item.BananaItem;
import net.mcreator.johnjulymcgamer.JohnJulyMcGamerMod;

import java.util.function.Function;

public class JohnJulyMcGamerModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(JohnJulyMcGamerMod.MODID);
	public static final DeferredItem<Item> GREG = block(JohnJulyMcGamerModBlocks.GREG);
	public static final DeferredItem<Item> FIRETHING = register("firething", FirethingItem::new);
	public static final DeferredItem<Item> BANANAICEFIRESWORD = register("bananaicefiresword", BananaicefireswordItem::new);
	public static final DeferredItem<Item> BANANA = register("banana", BananaItem::new);
	public static final DeferredItem<Item> GREGPLANT = block(JohnJulyMcGamerModBlocks.GREGPLANT);
	public static final DeferredItem<Item> GREGGUY_SPAWN_EGG = register("gregguy_spawn_egg", properties -> new SpawnEggItem(JohnJulyMcGamerModEntities.GREGGUY.get(), properties));
	public static final DeferredItem<Item> GLIG_SPAWN_EGG = register("glig_spawn_egg", properties -> new SpawnEggItem(JohnJulyMcGamerModEntities.GLIG.get(), properties));

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.registerItem(block.getId().getPath(), properties -> new BlockItem(block.get(), properties), new Item.Properties());
	}
}
