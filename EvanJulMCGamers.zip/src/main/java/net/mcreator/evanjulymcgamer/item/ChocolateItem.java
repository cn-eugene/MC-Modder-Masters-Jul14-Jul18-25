package net.mcreator.evanjulymcgamer.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class ChocolateItem extends Item {
	public ChocolateItem(Item.Properties properties) {
		super(properties.food((new FoodProperties.Builder()).nutrition(150).saturationModifier(0.3f).build()));
	}
}