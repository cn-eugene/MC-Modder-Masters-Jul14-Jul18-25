package net.mcreator.evanjulymcgamer.item;

import net.minecraft.world.item.Item;

public class ChocolateswordItem extends Item {
	public ChocolateswordItem(Item.Properties properties) {
		super(properties);
	}
}