package net.mcreator.evanjulymcgamer.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class FacenuggetItem extends Item {
	public FacenuggetItem(Item.Properties properties) {
		super(properties.stacksTo(99).food((new FoodProperties.Builder()).nutrition(200).saturationModifier(0.3f).alwaysEdible().build()));
	}
}