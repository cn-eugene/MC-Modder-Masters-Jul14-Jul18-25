package net.mcreator.evanjulymcgamer.item;

import net.minecraft.world.item.Item;

public class LeafingotItem extends Item {
	public LeafingotItem(Item.Properties properties) {
		super(properties);
	}
}