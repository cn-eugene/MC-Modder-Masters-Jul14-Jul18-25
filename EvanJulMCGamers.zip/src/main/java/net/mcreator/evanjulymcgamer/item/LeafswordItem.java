package net.mcreator.evanjulymcgamer.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class LeafswordItem extends SwordItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 10192, 4f, 0, 82, TagKey.create(Registries.ITEM, ResourceLocation.parse("evan_july__mc_gamer:leafsword_repair_items")));

	public LeafswordItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 103499f, 33f, properties.fireResistant().setNoCombineRepair());
	}

	@Override
	public ItemStack getCraftingRemainder(ItemStack itemstack) {
		return new ItemStack(this);
	}
}