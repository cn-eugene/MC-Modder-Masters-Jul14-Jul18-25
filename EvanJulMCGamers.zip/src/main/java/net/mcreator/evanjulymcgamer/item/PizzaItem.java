package net.mcreator.evanjulymcgamer.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class PizzaItem extends Item {
	public PizzaItem(Item.Properties properties) {
		super(properties.food((new FoodProperties.Builder()).nutrition(100).saturationModifier(0.3f).alwaysEdible().build()));
	}
}