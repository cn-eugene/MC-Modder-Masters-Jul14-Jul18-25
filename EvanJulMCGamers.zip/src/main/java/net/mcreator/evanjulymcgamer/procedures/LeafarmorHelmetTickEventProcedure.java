package net.mcreator.evanjulymcgamer.procedures;

public class LeafarmorHelmetTickEventProcedure {
	public static void execute() {
	}
}