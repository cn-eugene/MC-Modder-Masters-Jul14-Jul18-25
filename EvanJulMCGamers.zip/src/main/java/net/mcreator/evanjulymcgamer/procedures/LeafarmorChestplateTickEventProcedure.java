package net.mcreator.evanjulymcgamer.procedures;

public class LeafarmorChestplateTickEventProcedure {
	public static void execute() {
	}
}