/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.evanjulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.evanjulymcgamer.item.PizzaItem;
import net.mcreator.evanjulymcgamer.item.LeafswordItem;
import net.mcreator.evanjulymcgamer.item.LeafingotItem;
import net.mcreator.evanjulymcgamer.item.LeafdimentionItem;
import net.mcreator.evanjulymcgamer.item.LeafarmorItem;
import net.mcreator.evanjulymcgamer.item.FacenuggetItem;
import net.mcreator.evanjulymcgamer.item.ChocolateswordItem;
import net.mcreator.evanjulymcgamer.item.ChocolateItem;
import net.mcreator.evanjulymcgamer.EvanJulyMcGamerMod;

import java.util.function.Function;

public class EvanJulyMcGamerModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(EvanJulyMcGamerMod.MODID);
	public static final DeferredItem<Item> POOPBLOCK = block(EvanJulyMcGamerModBlocks.POOPBLOCK);
	public static final DeferredItem<Item> LEAFORE = block(EvanJulyMcGamerModBlocks.LEAFORE);
	public static final DeferredItem<Item> LEAFINGOT = register("leafingot", LeafingotItem::new);
	public static final DeferredItem<Item> LEAFSWORD = register("leafsword", LeafswordItem::new);
	public static final DeferredItem<Item> LEAFARMOR_HELMET = register("leafarmor_helmet", LeafarmorItem.Helmet::new);
	public static final DeferredItem<Item> LEAFARMOR_CHESTPLATE = register("leafarmor_chestplate", LeafarmorItem.Chestplate::new);
	public static final DeferredItem<Item> LEAFARMOR_LEGGINGS = register("leafarmor_leggings", LeafarmorItem.Leggings::new);
	public static final DeferredItem<Item> LEAFARMOR_BOOTS = register("leafarmor_boots", LeafarmorItem.Boots::new);
	public static final DeferredItem<Item> BOB_SPAWN_EGG = register("bob_spawn_egg", properties -> new SpawnEggItem(EvanJulyMcGamerModEntities.BOB.get(), properties));
	public static final DeferredItem<Item> PIZZA = register("pizza", PizzaItem::new);
	public static final DeferredItem<Item> FACENUGGET = register("facenugget", FacenuggetItem::new);
	public static final DeferredItem<Item> LEAFBLOCK = block(EvanJulyMcGamerModBlocks.LEAFBLOCK, new Item.Properties().stacksTo(99));
	public static final DeferredItem<Item> LEAFDIMENTION = register("leafdimention", LeafdimentionItem::new);
	public static final DeferredItem<Item> CHOCOLATE = register("chocolate", ChocolateItem::new);
	public static final DeferredItem<Item> CHOCOLATESWORD = register("chocolatesword", ChocolateswordItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}