/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.evanjulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.evanjulymcgamer.block.PoopblockBlock;
import net.mcreator.evanjulymcgamer.block.LeaforeBlock;
import net.mcreator.evanjulymcgamer.block.LeafdimentionPortalBlock;
import net.mcreator.evanjulymcgamer.block.LeafblockBlock;
import net.mcreator.evanjulymcgamer.EvanJulyMcGamerMod;

import java.util.function.Function;

public class EvanJulyMcGamerModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(EvanJulyMcGamerMod.MODID);
	public static final DeferredBlock<Block> POOPBLOCK = register("poopblock", PoopblockBlock::new);
	public static final DeferredBlock<Block> LEAFORE = register("leafore", LeaforeBlock::new);
	public static final DeferredBlock<Block> LEAFBLOCK = register("leafblock", LeafblockBlock::new);
	public static final DeferredBlock<Block> LEAFDIMENTION_PORTAL = register("leafdimention_portal", LeafdimentionPortalBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}