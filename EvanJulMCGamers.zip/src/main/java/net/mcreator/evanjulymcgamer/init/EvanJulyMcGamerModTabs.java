/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.evanjulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.evanjulymcgamer.EvanJulyMcGamerMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class EvanJulyMcGamerModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EvanJulyMcGamerMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(EvanJulyMcGamerModBlocks.POOPBLOCK.get().asItem());
			tabData.accept(EvanJulyMcGamerModItems.BOB_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(EvanJulyMcGamerModBlocks.LEAFORE.get().asItem());
			tabData.accept(EvanJulyMcGamerModBlocks.LEAFBLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(EvanJulyMcGamerModItems.LEAFINGOT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(EvanJulyMcGamerModItems.LEAFSWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(EvanJulyMcGamerModItems.LEAFARMOR_HELMET.get());
			tabData.accept(EvanJulyMcGamerModItems.LEAFARMOR_CHESTPLATE.get());
			tabData.accept(EvanJulyMcGamerModItems.LEAFARMOR_LEGGINGS.get());
			tabData.accept(EvanJulyMcGamerModItems.LEAFARMOR_BOOTS.get());
			tabData.accept(EvanJulyMcGamerModItems.CHOCOLATESWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(EvanJulyMcGamerModItems.PIZZA.get());
			tabData.accept(EvanJulyMcGamerModItems.FACENUGGET.get());
			tabData.accept(EvanJulyMcGamerModItems.LEAFDIMENTION.get());
			tabData.accept(EvanJulyMcGamerModItems.CHOCOLATE.get());
		}
	}
}