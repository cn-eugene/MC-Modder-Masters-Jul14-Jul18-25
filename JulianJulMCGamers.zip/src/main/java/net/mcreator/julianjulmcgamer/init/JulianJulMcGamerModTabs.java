/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.julianjulmcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.julianjulmcgamer.JulianJulMcGamerMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class JulianJulMcGamerModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, JulianJulMcGamerMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(JulianJulMcGamerModItems.CORUPTED_WORLD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(JulianJulMcGamerModItems.CORUPTED_ENTITY_SPAWN_EGG.get());
		}
	}
}