/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.julianjulmcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.julianjulmcgamer.item.CoruptedWorldItem;
import net.mcreator.julianjulmcgamer.JulianJulMcGamerMod;

import java.util.function.Function;

public class JulianJulMcGamerModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(JulianJulMcGamerMod.MODID);
	public static final DeferredItem<Item> CORUPTED_GRASS = block(JulianJulMcGamerModBlocks.CORUPTED_GRASS);
	public static final DeferredItem<Item> CORUPTED_WORLD = register("corupted_world", CoruptedWorldItem::new);
	public static final DeferredItem<Item> CORUPTED_ENTITY_SPAWN_EGG = register("corupted_entity_spawn_egg", properties -> new SpawnEggItem(JulianJulMcGamerModEntities.CORUPTED_ENTITY.get(), properties));

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}