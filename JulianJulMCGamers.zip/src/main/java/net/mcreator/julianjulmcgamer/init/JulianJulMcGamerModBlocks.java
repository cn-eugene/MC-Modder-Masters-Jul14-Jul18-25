/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.julianjulmcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.julianjulmcgamer.block.CoruptedWorldPortalBlock;
import net.mcreator.julianjulmcgamer.block.CoruptedGrassBlock;
import net.mcreator.julianjulmcgamer.JulianJulMcGamerMod;

import java.util.function.Function;

public class JulianJulMcGamerModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(JulianJulMcGamerMod.MODID);
	public static final DeferredBlock<Block> CORUPTED_GRASS = register("corupted_grass", CoruptedGrassBlock::new);
	public static final DeferredBlock<Block> CORUPTED_WORLD_PORTAL = register("corupted_world_portal", CoruptedWorldPortalBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}