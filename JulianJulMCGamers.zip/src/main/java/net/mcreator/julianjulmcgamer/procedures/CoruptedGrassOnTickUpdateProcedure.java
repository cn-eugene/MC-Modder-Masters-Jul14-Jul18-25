package net.mcreator.julianjulmcgamer.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.julianjulmcgamer.init.JulianJulMcGamerModEntities;
import net.mcreator.julianjulmcgamer.JulianJulMcGamerMod;

import java.util.Random;

public class CoruptedGrassOnTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		JulianJulMcGamerMod.queueServerWork((int) new Random().nextGaussian(), () -> {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = JulianJulMcGamerModEntities.CORUPTED_ENTITY.get().spawn(_level, BlockPos.containing(x, y, z), EntitySpawnReason.MOB_SUMMONED);
				if (entityToSpawn != null) {
					entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
				}
			}
		});
	}
}