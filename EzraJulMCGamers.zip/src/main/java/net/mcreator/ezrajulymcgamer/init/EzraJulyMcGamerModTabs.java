
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ezrajulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.ezrajulymcgamer.EzraJulyMcGamerMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class EzraJulyMcGamerModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EzraJulyMcGamerMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(EzraJulyMcGamerModBlocks.GRASS.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(EzraJulyMcGamerModItems.GRASS_INGOT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(EzraJulyMcGamerModItems.GRASSSORD.get());
			tabData.accept(EzraJulyMcGamerModItems.GRASSAXE.get());
			tabData.accept(EzraJulyMcGamerModItems.GRASSPICKAXE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(EzraJulyMcGamerModItems.GRASSARMER_HELMET.get());
			tabData.accept(EzraJulyMcGamerModItems.GRASSARMER_CHESTPLATE.get());
			tabData.accept(EzraJulyMcGamerModItems.GRASSARMER_LEGGINGS.get());
			tabData.accept(EzraJulyMcGamerModItems.GRASSARMER_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(EzraJulyMcGamerModItems.WERT_SPAWN_EGG.get());
		}
	}
}
