
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ezrajulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.ezrajulymcgamer.item.GrasssordItem;
import net.mcreator.ezrajulymcgamer.item.GrasspickaxeItem;
import net.mcreator.ezrajulymcgamer.item.GrassaxeItem;
import net.mcreator.ezrajulymcgamer.item.GrassarmerItem;
import net.mcreator.ezrajulymcgamer.item.GrassIngotItem;
import net.mcreator.ezrajulymcgamer.EzraJulyMcGamerMod;

import java.util.function.Function;

public class EzraJulyMcGamerModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(EzraJulyMcGamerMod.MODID);
	public static final DeferredItem<Item> GRASS = block(EzraJulyMcGamerModBlocks.GRASS);
	public static final DeferredItem<Item> GRASS_INGOT = register("grass_ingot", GrassIngotItem::new);
	public static final DeferredItem<Item> GRASSSORD = register("grasssord", GrasssordItem::new);
	public static final DeferredItem<Item> GRASSAXE = register("grassaxe", GrassaxeItem::new);
	public static final DeferredItem<Item> GRASSARMER_HELMET = register("grassarmer_helmet", GrassarmerItem.Helmet::new);
	public static final DeferredItem<Item> GRASSARMER_CHESTPLATE = register("grassarmer_chestplate", GrassarmerItem.Chestplate::new);
	public static final DeferredItem<Item> GRASSARMER_LEGGINGS = register("grassarmer_leggings", GrassarmerItem.Leggings::new);
	public static final DeferredItem<Item> GRASSARMER_BOOTS = register("grassarmer_boots", GrassarmerItem.Boots::new);
	public static final DeferredItem<Item> REDGRASS = block(EzraJulyMcGamerModBlocks.REDGRASS);
	public static final DeferredItem<Item> WERT_SPAWN_EGG = register("wert_spawn_egg", properties -> new SpawnEggItem(EzraJulyMcGamerModEntities.WERT.get(), properties));
	public static final DeferredItem<Item> GRASSPICKAXE = register("grasspickaxe", GrasspickaxeItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.registerItem(block.getId().getPath(), properties -> new BlockItem(block.get(), properties), new Item.Properties());
	}
}
