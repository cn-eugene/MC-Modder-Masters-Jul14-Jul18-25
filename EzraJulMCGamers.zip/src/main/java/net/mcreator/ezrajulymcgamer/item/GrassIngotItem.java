
package net.mcreator.ezrajulymcgamer.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class GrassIngotItem extends Item {
	public GrassIngotItem(Item.Properties properties) {
		super(properties.rarity(Rarity.COMMON).stacksTo(64));
	}
}
