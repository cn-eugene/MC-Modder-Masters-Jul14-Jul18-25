/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ellisjulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.ellisjulymcgamer.item.TinybluududItem;
import net.mcreator.ellisjulymcgamer.item.RectangularBluududItem;
import net.mcreator.ellisjulymcgamer.item.Pr3ttyPr11ncesCoreItem;
import net.mcreator.ellisjulymcgamer.item.C00lkiddCoreItem;
import net.mcreator.ellisjulymcgamer.item.BluuswordItem;
import net.mcreator.ellisjulymcgamer.item.BluududcoreItem;
import net.mcreator.ellisjulymcgamer.item.BluuShovelItem;
import net.mcreator.ellisjulymcgamer.item.BluuPickaxeItem;
import net.mcreator.ellisjulymcgamer.item.BLUUDUDTOTEMItem;
import net.mcreator.ellisjulymcgamer.item.BLUUAXItem;
import net.mcreator.ellisjulymcgamer.EllisJulyMcGamerMod;

import java.util.function.Function;

public class EllisJulyMcGamerModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(EllisJulyMcGamerMod.MODID);
	public static final DeferredItem<Item> SIGMABLOCK = block(EllisJulyMcGamerModBlocks.SIGMABLOCK);
	public static final DeferredItem<Item> BLUUSWORD = register("bluusword", BluuswordItem::new);
	public static final DeferredItem<Item> BLUUORE = block(EllisJulyMcGamerModBlocks.BLUUORE);
	public static final DeferredItem<Item> RECTANGULAR_BLUUDUD = register("rectangular_bluudud", RectangularBluududItem::new);
	public static final DeferredItem<Item> TINYBLUUDUD = register("tinybluudud", TinybluududItem::new);
	public static final DeferredItem<Item> BLUUDUD_SPAWN_EGG = register("bluudud_spawn_egg", properties -> new SpawnEggItem(EllisJulyMcGamerModEntities.BLUUDUD.get(), properties));
	public static final DeferredItem<Item> BLUUDUDCORE = register("bluududcore", BluududcoreItem::new);
	public static final DeferredItem<Item> C_00LKIDD_SPAWN_EGG = register("c_00lkidd_spawn_egg", properties -> new SpawnEggItem(EllisJulyMcGamerModEntities.C_00LKIDD.get(), properties));
	public static final DeferredItem<Item> C_00LKIDD_CORE = register("c_00lkidd_core", C00lkiddCoreItem::new);
	public static final DeferredItem<Item> PR_3TTY_PR_11NCES_SPAWN_EGG = register("pr_3tty_pr_11nces_spawn_egg", properties -> new SpawnEggItem(EllisJulyMcGamerModEntities.PR_3TTY_PR_11NCES.get(), properties));
	public static final DeferredItem<Item> PR_3TTY_PR_11NCES_CORE = register("pr_3tty_pr_11nces_core", Pr3ttyPr11ncesCoreItem::new);
	public static final DeferredItem<Item> BLUUDUDTOTEM = register("bluududtotem", BLUUDUDTOTEMItem::new);
	public static final DeferredItem<Item> BLUU_PICKAXE = register("bluu_pickaxe", BluuPickaxeItem::new);
	public static final DeferredItem<Item> BLUUAX = register("bluuax", BLUUAXItem::new);
	public static final DeferredItem<Item> BLUU_SHOVEL = register("bluu_shovel", BluuShovelItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}