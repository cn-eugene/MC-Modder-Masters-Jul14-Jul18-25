/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ellisjulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.ellisjulymcgamer.entity.Pr3ttyPr11ncesEntity;
import net.mcreator.ellisjulymcgamer.entity.C00lkiddEntity;
import net.mcreator.ellisjulymcgamer.entity.BluududEntity;
import net.mcreator.ellisjulymcgamer.EllisJulyMcGamerMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class EllisJulyMcGamerModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, EllisJulyMcGamerMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<BluududEntity>> BLUUDUD = register("bluudud",
			EntityType.Builder.<BluududEntity>of(BluududEntity::new, MobCategory.AMBIENT).setShouldReceiveVelocityUpdates(true).setTrackingRange(10000).setUpdateInterval(3).fireImmune().ridingOffset(-0.6f).sized(1f, 2f));
	public static final DeferredHolder<EntityType<?>, EntityType<C00lkiddEntity>> C_00LKIDD = register("c_00lkidd",
			EntityType.Builder.<C00lkiddEntity>of(C00lkiddEntity::new, MobCategory.AMBIENT).setShouldReceiveVelocityUpdates(true).setTrackingRange(10000).setUpdateInterval(3)

					.ridingOffset(-0.6f).sized(0.6f, 1.9f));
	public static final DeferredHolder<EntityType<?>, EntityType<Pr3ttyPr11ncesEntity>> PR_3TTY_PR_11NCES = register("pr_3tty_pr_11nces",
			EntityType.Builder.<Pr3ttyPr11ncesEntity>of(Pr3ttyPr11ncesEntity::new, MobCategory.AMBIENT).setShouldReceiveVelocityUpdates(true).setTrackingRange(10000).setUpdateInterval(3)

					.ridingOffset(-0.6f).sized(0.6f, 1.8f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(ResourceKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(EllisJulyMcGamerMod.MODID, registryname))));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		BluududEntity.init(event);
		C00lkiddEntity.init(event);
		Pr3ttyPr11ncesEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(BLUUDUD.get(), BluududEntity.createAttributes().build());
		event.put(C_00LKIDD.get(), C00lkiddEntity.createAttributes().build());
		event.put(PR_3TTY_PR_11NCES.get(), Pr3ttyPr11ncesEntity.createAttributes().build());
	}
}