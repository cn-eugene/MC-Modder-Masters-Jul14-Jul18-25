/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ellisjulymcgamer.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.ellisjulymcgamer.client.renderer.Pr3ttyPr11ncesRenderer;
import net.mcreator.ellisjulymcgamer.client.renderer.C00lkiddRenderer;
import net.mcreator.ellisjulymcgamer.client.renderer.BluududRenderer;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class EllisJulyMcGamerModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(EllisJulyMcGamerModEntities.BLUUDUD.get(), BluududRenderer::new);
		event.registerEntityRenderer(EllisJulyMcGamerModEntities.C_00LKIDD.get(), C00lkiddRenderer::new);
		event.registerEntityRenderer(EllisJulyMcGamerModEntities.PR_3TTY_PR_11NCES.get(), Pr3ttyPr11ncesRenderer::new);
	}
}