/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ellisjulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.core.registries.Registries;

import net.mcreator.ellisjulymcgamer.EllisJulyMcGamerMod;

public class EllisJulyMcGamerModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(Registries.POTION, EllisJulyMcGamerMod.MODID);
	public static final DeferredHolder<Potion, Potion> PEE = REGISTRY.register("pee", () -> new Potion("pee", new MobEffectInstance(MobEffects.DAMAGE_BOOST, 2000, 0, false, true), new MobEffectInstance(MobEffects.WEAKNESS, 2000, 0, false, true)));
}