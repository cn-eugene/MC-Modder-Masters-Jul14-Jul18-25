package net.mcreator.ellisjulymcgamer.item;

import net.minecraft.world.item.Item;

public class Pr3ttyPr11ncesCoreItem extends Item {
	public Pr3ttyPr11ncesCoreItem(Item.Properties properties) {
		super(properties);
	}
}