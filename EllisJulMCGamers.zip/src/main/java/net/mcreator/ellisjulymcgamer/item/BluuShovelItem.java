package net.mcreator.ellisjulymcgamer.item;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class BluuShovelItem extends Item {
	public BluuShovelItem(Item.Properties properties) {
		super(properties);
	}

	@Override
	public float getDestroySpeed(ItemStack itemstack, BlockState state) {
		return 3f;
	}
}