package net.mcreator.ellisjulymcgamer.item;

import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class TinybluududItem extends ShieldItem {
	public TinybluududItem(Item.Properties properties) {
		super(properties.durability(100).fireResistant().repairable(TagKey.create(Registries.ITEM, ResourceLocation.parse("ellis__july_mc_gamer:tinybluudud_repair_items"))));
	}
}