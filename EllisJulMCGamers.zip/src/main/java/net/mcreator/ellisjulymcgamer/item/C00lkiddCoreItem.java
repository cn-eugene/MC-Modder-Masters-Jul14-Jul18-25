package net.mcreator.ellisjulymcgamer.item;

import net.minecraft.world.item.Item;

public class C00lkiddCoreItem extends Item {
	public C00lkiddCoreItem(Item.Properties properties) {
		super(properties);
	}
}