package net.mcreator.ellisjulymcgamer.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class RectangularBluududItem extends Item {
	public RectangularBluududItem(Item.Properties properties) {
		super(properties.rarity(Rarity.RARE));
	}
}