/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jacobjulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.jacobjulymcgamer.item.WebshooterItem;
import net.mcreator.jacobjulymcgamer.item.SpidermanarmorItem;
import net.mcreator.jacobjulymcgamer.item.KatanaItem;
import net.mcreator.jacobjulymcgamer.JacobJulyMcGamerMod;

import java.util.function.Function;

public class JacobJulyMcGamerModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(JacobJulyMcGamerMod.MODID);
	public static final DeferredItem<Item> CYBORG = block(JacobJulyMcGamerModBlocks.CYBORG);
	public static final DeferredItem<Item> SPIDERMANARMOR_HELMET = register("spidermanarmor_helmet", SpidermanarmorItem.Helmet::new);
	public static final DeferredItem<Item> SPIDERMANARMOR_CHESTPLATE = register("spidermanarmor_chestplate", SpidermanarmorItem.Chestplate::new);
	public static final DeferredItem<Item> SPIDERMANARMOR_LEGGINGS = register("spidermanarmor_leggings", SpidermanarmorItem.Leggings::new);
	public static final DeferredItem<Item> SPIDERMANARMOR_BOOTS = register("spidermanarmor_boots", SpidermanarmorItem.Boots::new);
	public static final DeferredItem<Item> WEBSHOOTER = register("webshooter", WebshooterItem::new);
	public static final DeferredItem<Item> DEADPOOL_KID_SPAWN_EGG = register("deadpool_kid_spawn_egg", properties -> new SpawnEggItem(JacobJulyMcGamerModEntities.DEADPOOL_KID.get(), properties));
	public static final DeferredItem<Item> KATANA = register("katana", KatanaItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}