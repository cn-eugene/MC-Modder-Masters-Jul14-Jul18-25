package net.mcreator.jacobjulymcgamer.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.jacobjulymcgamer.entity.DeadpoolKidEntity;
import net.mcreator.jacobjulymcgamer.client.model.animations.Deadpool_KidAnimation;

public class DeadpoolKidRenderer extends HumanoidMobRenderer<DeadpoolKidEntity, HumanoidRenderState, HumanoidModel<HumanoidRenderState>> {
	private DeadpoolKidEntity entity = null;

	public DeadpoolKidRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getEquipmentRenderer()));
	}

	@Override
	public HumanoidRenderState createRenderState() {
		return new HumanoidRenderState();
	}

	@Override
	public void extractRenderState(DeadpoolKidEntity entity, HumanoidRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		this.entity = entity;
		if (this.model instanceof AnimatedModel) {
			((AnimatedModel) this.model).setEntity(entity);
		}
	}

	@Override
	public ResourceLocation getTextureLocation(HumanoidRenderState state) {
		return ResourceLocation.parse("jacob_july_mc_gamer:textures/entities/deadpool_26.png");
	}

	private static final class AnimatedModel extends HumanoidModel<HumanoidRenderState> {
		private DeadpoolKidEntity entity = null;

		public AnimatedModel(ModelPart root) {
			super(root);
		}

		public void setEntity(DeadpoolKidEntity entity) {
			this.entity = entity;
		}

		@Override
		public void setupAnim(HumanoidRenderState state) {
			super.setupAnim(state);
			this.animateWalk(Deadpool_KidAnimation.dash_atack, state.walkAnimationPos, state.walkAnimationSpeed, 0.9f, 1f);
		}
	}
}