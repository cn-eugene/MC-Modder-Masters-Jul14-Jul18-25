
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.demirjulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.demirjulymcgamer.block.SddsdsddsBlock;
import net.mcreator.demirjulymcgamer.block.COrruptdirtBlock;
import net.mcreator.demirjulymcgamer.DemirJulyMcGamerMod;

import java.util.function.Function;

public class DemirJulyMcGamerModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(DemirJulyMcGamerMod.MODID);
	public static final DeferredBlock<Block> C_ORRUPTDIRT = register("c_orruptdirt", COrruptdirtBlock::new);
	public static final DeferredBlock<Block> SDDSDSDDS = register("sddsdsdds", SddsdsddsBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}
