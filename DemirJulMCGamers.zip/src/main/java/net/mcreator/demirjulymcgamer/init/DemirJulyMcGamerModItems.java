
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.demirjulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.demirjulymcgamer.item.EtItem;
import net.mcreator.demirjulymcgamer.item.DrdhhdjdfjItem;
import net.mcreator.demirjulymcgamer.DemirJulyMcGamerMod;

import java.util.function.Function;

public class DemirJulyMcGamerModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(DemirJulyMcGamerMod.MODID);
	public static final DeferredItem<Item> C_ORRUPTDIRT = block(DemirJulyMcGamerModBlocks.C_ORRUPTDIRT);
	public static final DeferredItem<Item> SDDSDSDDS = block(DemirJulyMcGamerModBlocks.SDDSDSDDS);
	public static final DeferredItem<Item> DRDHHDJDFJ = register("drdhhdjdfj", DrdhhdjdfjItem::new);
	public static final DeferredItem<Item> ET = register("et", EtItem::new);
	public static final DeferredItem<Item> E_SPAWN_EGG = register("e_spawn_egg", properties -> new SpawnEggItem(DemirJulyMcGamerModEntities.E.get(), properties));
	public static final DeferredItem<Item> ETE_SPAWN_EGG = register("ete_spawn_egg", properties -> new SpawnEggItem(DemirJulyMcGamerModEntities.ETE.get(), properties));

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.registerItem(block.getId().getPath(), properties -> new BlockItem(block.get(), properties), new Item.Properties());
	}
}
