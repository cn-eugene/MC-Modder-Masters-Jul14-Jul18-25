
package net.mcreator.helixjulymcgamer.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class RubyswordItem extends SwordItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 256, 0f, 0, 12, TagKey.create(Registries.ITEM, ResourceLocation.parse("helix_july_mc_gamer:rubysword_repair_items")));

	public RubyswordItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 17f, -1f, properties);
	}
}
