
package net.mcreator.helixjulymcgamer.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class RubyaxeItem extends AxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 256, 15f, 0, 12, TagKey.create(Registries.ITEM, ResourceLocation.parse("helix_july_mc_gamer:rubyaxe_repair_items")));

	public RubyaxeItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 23f, -2f, properties);
	}
}
