
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.helixjulymcgamer.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.helixjulymcgamer.HelixJulyMcGamerMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class HelixJulyMcGamerModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, HelixJulyMcGamerMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(HelixJulyMcGamerModBlocks.BLOCKOFRUBY.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(HelixJulyMcGamerModItems.RUBY.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(HelixJulyMcGamerModItems.RUBYSWORD.get());
			tabData.accept(HelixJulyMcGamerModItems.RUBYPICKAXE.get());
			tabData.accept(HelixJulyMcGamerModItems.RUBYAXE.get());
			tabData.accept(HelixJulyMcGamerModItems.RUBYSHOVEL.get());
			tabData.accept(HelixJulyMcGamerModItems.RUBYHOE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(HelixJulyMcGamerModBlocks.RUBYORE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(HelixJulyMcGamerModItems.RUBYARMOR_HELMET.get());
			tabData.accept(HelixJulyMcGamerModItems.RUBYARMOR_CHESTPLATE.get());
			tabData.accept(HelixJulyMcGamerModItems.RUBYARMOR_LEGGINGS.get());
			tabData.accept(HelixJulyMcGamerModItems.RUBYARMOR_BOOTS.get());
			tabData.accept(HelixJulyMcGamerModItems.RUBYGUN.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(HelixJulyMcGamerModItems.RUBYCREATURE_SPAWN_EGG.get());
		}
	}
}
